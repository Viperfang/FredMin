<?php

// Page name
$pagename ="Server Stats";

// Include Files
include ('../head.php');
include ('../config/config.php');

// Main Content
cmdline('System Name','cat /etc/hostname');
cmdline('IP Address','hostname -I');
cmdline('System Uptime','uptime');
cmdline('Operating System','uname -a');
cmdline('System Time','date');
// cmdline('Installed Packages','apt list --installed | less');

// Footer
include ('foot.php');

// Cmd Line Print Function
function cmdline($name,$cmd) {
    echo "<strong>$name:</strong>";
    echo "<div class='catout'>"; // Display on correct lines
    $cmdline = shell_exec("$cmd");
    echo "$cmdline";
    echo "</div>";
    echo "<br />";
}

?>
<?php

// Page name
$pagename ="Test Program";

// Include Files
include ('../head.php');
include ('../config/config.php');

// Main Content
echo "<h2>Test Program</h2>";

// Footer
include ('foot.php');
?>
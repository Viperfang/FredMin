<?php

// Page name
$pagename ="Kernal Log File";

// Include Files
include ('./config/config.php');
include ('head.php');
include ('../functions.php');

phpinfo();

// Footer
include ('foot.php');     
?>

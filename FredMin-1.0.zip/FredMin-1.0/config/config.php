<?php

// Website Name
$controlname = 'Fredmin';

?>

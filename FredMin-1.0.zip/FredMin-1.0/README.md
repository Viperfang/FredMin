# FredMin - Ver 0.9 (pre release)
### (some features may not currently work)

A super small and lightweight Server Administration Tool small enough to fit on a floppy disk.
Weighing in at under 50kb including images, this powerful little beast will happiliy sit on the most restricted servers on the cloud.

Just remember to put it in a password protected folder.

## Installation
- You will need to install sshpass
run command: sudo apt-get install sshpass -y

- Add a sudo user WWW-DATA
enter SU to access root User
enter visudo
then add user to the sudoers file:
www-data ALL=(ALL) NOPASSWD: ALL

Have fun, and run with it!

## Screenshot

![image](https://raw.githubusercontent.com/sn0wlink/FredMin/master/screenshot.png)
